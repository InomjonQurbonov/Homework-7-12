from django.contrib import admin
from .models import Members, Organizations

admin.site.register(Members)
admin.site.register(Organizations)
