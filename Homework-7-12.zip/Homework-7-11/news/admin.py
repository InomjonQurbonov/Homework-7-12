from django.contrib import admin
from .models import News, OurWorks

admin.site.register(News)
admin.site.register(OurWorks)
